import asyncio,ipaddress,json,struct,time,collections,logging
POLICY=json.load(open('/etc/smartdns/policy.json'))
CLIENTS=set(POLICY['allowed_clients'])
ROOTS=POLICY['roots'];EXACT=set(POLICY['exact'])
ACTIVE=collections.Counter();RECENT=collections.defaultdict(collections.deque);PRUNE_AT=0
logging.basicConfig(level=logging.INFO,format='%(asctime)s %(message)s')
def permitted(h):return h in EXACT or any(h==r or h.endswith('.'+r) for r in ROOTS)
def sni(data):
 if len(data)<4 or data[0]!=1:raise ValueError('not client hello')
 n=int.from_bytes(data[1:4],'big'); b=data[4:4+n]
 p=34; p+=1+b[p]; c=int.from_bytes(b[p:p+2],'big');p+=2+c;p+=1+b[p]
 if p+2>len(b):raise ValueError('no extensions')
 end=p+2+int.from_bytes(b[p:p+2],'big');p+=2
 while p+4<=end:
  typ,size=struct.unpack('!HH',b[p:p+4]);p+=4;ext=b[p:p+size];p+=size
  if typ==0:
   q=2
   while q+3<=len(ext):
    t=ext[q];ln=int.from_bytes(ext[q+1:q+3],'big');q+=3
    if t==0:return ext[q:q+ln].decode('ascii').lower().rstrip('.')
    q+=ln
 raise ValueError('no SNI')
async def pipe(r,w):
 while True:
  b=await asyncio.wait_for(r.read(65536),600)
  if not b:break
  w.write(b);await w.drain()
 try:w.write_eof()
 except (OSError,AttributeError):pass
async def handle(r,w):
 global PRUNE_AT
 src=None;up=None; counted=False
 try:
  line=await asyncio.wait_for(r.readuntil(b'\r\n'),5)
  parts=line.decode('ascii').split()
  if len(parts)!=6 or parts[0]!='PROXY' or parts[1] not in ('TCP4','TCP6'):raise ValueError('bad proxy header')
  src=parts[2]
  ipaddress.ip_address(src)
  now=time.monotonic()
  if now>=PRUNE_AT:
   PRUNE_AT=now+60
   for old in list(RECENT):
    if not ACTIVE[old] and (not RECENT[old] or RECENT[old][-1]<now-120):
     RECENT.pop(old,None);ACTIVE.pop(old,None)
  if src not in RECENT and len(RECENT)>=10000:raise ValueError('source capacity')
  if sum(ACTIVE.values())>=512:raise ValueError('global connection capacity')
  now=time.monotonic();q=RECENT[src]
  while q and q[0]<now-60:q.popleft()
  if len(q)>=240 or ACTIVE[src]>=64:raise ValueError('rate limit')
  q.append(now);ACTIVE[src]+=1;counted=True
  wire=b'';hello=b''
  for _ in range(8):
   head=await asyncio.wait_for(r.readexactly(5),5)
   ln=int.from_bytes(head[3:5],'big')
   if head[0]!=22 or ln>18432:raise ValueError('not TLS handshake')
   body=await asyncio.wait_for(r.readexactly(ln),5);wire+=head+body;hello+=body
   if len(hello)>=4 and len(hello)>=4+int.from_bytes(hello[1:4],'big'):break
  host=sni(hello)
  if not permitted(host):raise ValueError('destination not allowed')
  addrs=await asyncio.wait_for(asyncio.get_running_loop().getaddrinfo(host,443,type=1),6)
  safe=[]
  for a in addrs:
   ip=ipaddress.ip_address(a[4][0])
   if ip.is_global and str(ip) not in ('185.249.155.218','77.239.102.114','2a01:ecc0:200:f5e::2'):safe.append(a[4][0])
  if not safe:raise ValueError('unsafe or recursive upstream')
  err=None
  for addr in sorted(set(safe),key=lambda x:':' in x):
   try:ur,up=await asyncio.wait_for(asyncio.open_connection(addr,443),6);break
   except (OSError,asyncio.TimeoutError) as e:err=e
  if up is None:raise OSError('upstream unavailable') from err
  if host in ('auth.x.ai','openai.com','chatgpt.com','claude.ai'):logging.info('site diagnostic: source=%s host=%s upstream=%s hello_bytes=%s',src,host,addr,len(wire))
  up.write(wire);await up.drain()
  tasks=[asyncio.create_task(pipe(r,up)),asyncio.create_task(pipe(ur,w))]
  try:
   done,pending=await asyncio.wait(tasks,return_when=asyncio.FIRST_COMPLETED)
   await asyncio.wait_for(asyncio.gather(*pending,return_exceptions=True),10)
  finally:
   for t in tasks:t.cancel()
   await asyncio.gather(*tasks,return_exceptions=True)
 except (Exception,asyncio.CancelledError) as e:
  if not isinstance(e,(asyncio.IncompleteReadError,ConnectionResetError)):logging.info('relay closed: %s',type(e).__name__)
 finally:
  if counted:ACTIVE[src]-=1
  if up:up.close()
  w.close()
  try:await w.wait_closed()
  except OSError:pass
async def main():
 server=await asyncio.start_server(handle,'127.0.0.1',15443,limit=65536)
 async with server:await server.serve_forever()
asyncio.run(main())
