import base64,collections,datetime,hashlib,json,os,random,shutil,socket,ssl,struct,subprocess,threading,time,urllib.request,urllib.parse
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer

POLICY=json.load(open('/etc/smartdns/policy.json'))
CATALOG=json.load(open('/etc/smartdns/catalog.json'))
SRV_IP='185.249.155.218'
ENDPOINTS={'doh':'https://dns.manima.ru/dns-query','dot':'manima.ru','dns':SRV_IP}
DOMAIN_SERVICES={}
for entry in CATALOG:
 for hostname in entry['domains']:
  DOMAIN_SERVICES.setdefault(hostname,(entry['id'],entry['category']))
BRANDS={}
for entry in CATALOG:
 for name in ['ChatGPT','Claude','OpenCode']:
  if entry['name'].startswith(name) and name not in BRANDS:BRANDS[name]=entry['id']
EVENTS=collections.deque(maxlen=60000)
SEEN=collections.OrderedDict()
MINUTES=collections.OrderedDict()
LOCK=threading.Lock()
SEQUENCE=0
LAST_OK=0
LAST_DNS_OK=0
STARTED=time.time()
def service(host):
 host=host.lower().rstrip('.')
 if host in DOMAIN_SERVICES:return DOMAIN_SERVICES[host]
 for suffix,brand in [('chatgpt.com','ChatGPT'),('openai.com','ChatGPT'),('oaistatic.com','ChatGPT'),('oaiusercontent.com','ChatGPT'),('claude.ai','Claude'),('claude.com','Claude'),('claudeusercontent.com','Claude'),('claudemcpcontent.com','Claude'),('anthropic.com','Claude'),('opencode.ai','OpenCode')]:
  if host==suffix or host.endswith('.'+suffix):return BRANDS[brand],'ai'
 return 'direct','direct'
def rebuild_minutes():
 buckets=collections.OrderedDict()
 for x in EVENTS:
  m=x['ts']//60000*60000
  b=buckets.get(m)
  if b is None:
   b={'t':m,'q':0,'doh':0,'dot':0,'dns':0};buckets[m]=b
  b['q']+=1
  if x['protocol'] in ('doh','dot','dns'):b[x['protocol']]+=1
 while len(buckets)>180:buckets.popitem(last=False)
 return buckets
def poll():
 global SEQUENCE,LAST_OK,LAST_DNS_OK,MINUTES
 while True:
  try:
   with urllib.request.urlopen('http://127.0.0.1:13000/control/querylog?limit=1000',timeout=4) as r:data=json.load(r)['data']
   with LOCK:
    for item in reversed(data):
     question=item.get('question',{})
     client=item.get('client','')
     if client=='127.0.0.1' and question.get('name')=='dns-health.invalid':continue
     ident=hashlib.sha256((item['time']+'|'+client+'|'+question.get('name','')+'|'+question.get('type','')).encode()).hexdigest()
     if ident in SEEN:continue
     SEEN[ident]=None
     ts=int(datetime.datetime.fromisoformat(item['time']).timestamp()*1000)
     if ts<time.time()*1000-3600000:continue
     SEQUENCE+=1
     service_id,category=service(question.get('name',''))
     EVENTS.append({'id':str(SEQUENCE),'ts':ts,'protocol':{'doh':'doh','dot':'dot'}.get(item.get('client_proto'),'dns'),'service':service_id,'category':category,'count':1,'client':client})
    while len(SEEN)>100000:SEEN.popitem(last=False)
    while EVENTS and EVENTS[0]['ts']<time.time()*1000-3600000:EVENTS.popleft()
    MINUTES=rebuild_minutes()
    LAST_OK=time.time()
   if time.time()-LAST_DNS_OK>=8:
    query=b'\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00'+b'\x0adns-health\x07invalid\0'+struct.pack('!HH',1,1)
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as dns:
     dns.settimeout(1);dns.sendto(query,('127.0.0.1',53));reply=dns.recv(4096)
    if reply[:2]==query[:2] and reply[2]&128:LAST_DNS_OK=time.time()
  except Exception:pass
  time.sleep(2)
# ---------- system sampling ----------
SYS={'at':0,'data':{}}
CPU_PREV=[None]
def read_cpu():
 with open('/proc/stat') as f:vals=list(map(int,f.readline().split()[1:8]))
 idle=vals[3]+vals[4];return idle,sum(vals)
def sample_system():
 global SYS
 try:
  idle,total=read_cpu();prev=CPU_PREV[0];CPU_PREV[0]=(idle,total)
  cpu=None
  if prev and total>prev[1]:cpu=round((1-(idle-prev[0])/(total-prev[1]))*100,1)
  with open('/proc/uptime') as f:up=float(f.read().split()[0])
  SYS={'at':int(time.time()*1000),'data':{'cpuPct':cpu,'loadAvg':[round(x,2) for x in os.getloadavg()],'uptimeSec':int(up)}}
 except Exception as e:SYS={'at':int(time.time()*1000),'data':{'error':type(e).__name__}}
CERT={'at':0,'data':{}}
def note_cert(cert):
 try:
  na=(cert or {}).get('notAfter')
  if not na:return
  dt=datetime.datetime.strptime(na,'%b %d %H:%M:%S %Y %Z').replace(tzinfo=datetime.timezone.utc)
  with LOCK:CERT.update({'at':int(time.time()*1000),'data':{'notAfter':dt.isoformat(),'daysLeft':(dt-datetime.datetime.now(datetime.timezone.utc)).days}})
 except Exception:pass
def sample_cert():
 pass
def system_loop():
 sample_system()
 while True:
  time.sleep(15)
  sample_system()
def read_reachability():
 try:
  with open('/var/www/smartdns/reachability.json',encoding='utf-8') as f:return json.load(f)
 except (OSError,ValueError):return {}
# ---------- diagnostics probes (localhost, honest source labels) ----------
def dns_packet(name,qtype=1):
 ident=random.randint(1,65535)
 h=struct.pack('!HHHHHH',ident,0x0100,1,0,0,0)
 q=b''.join(bytes([len(p)])+p.encode('ascii') for p in name.split('.'))+b'\x00'+struct.pack('!HH',qtype,1)
 return ident,h+q
def parse_reply(buf,ident):
 if len(buf)<12:raise ValueError('short reply')
 rid,flags,qd,an,n1,n2=struct.unpack('!HHHHHH',buf[:12])
 if rid!=ident:raise ValueError('id mismatch')
 if not flags&0x8000:raise ValueError('not a response')
 rcode=flags&0x000F
 off=12
 for _ in range(qd):
  while True:
   if off>=len(buf):raise ValueError('bad question')
   ln=buf[off];off+=1
   if ln==0:break
   if ln&0xC0:off+=1;break
   off+=ln
  off+=4
 ips=[]
 for _ in range(an):
  if off>=len(buf):break
  if buf[off]&0xC0:off+=2
  else:
   while True:
    if off>=len(buf):raise ValueError('bad rr name')
    ln=buf[off];off+=1
    if ln==0:break
    if ln&0xC0:off+=1;break
    off+=ln
  if off+10>len(buf):break
  typ,cls,ttl,rdlen=struct.unpack('!HHIH',buf[off:off+10]);off+=10
  if off+rdlen>len(buf):break
  rdata=buf[off:off+rdlen];off+=rdlen
  if typ==1 and rdlen==4:ips.append('.'.join(str(b) for b in rdata))
 return rcode,ips
def udp_query(name,timeout=4):
 ident,pkt=dns_packet(name)
 with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
  s.settimeout(timeout);t0=time.monotonic();s.sendto(pkt,('127.0.0.1',53));buf,_=s.recvfrom(4096);dt=(time.monotonic()-t0)*1000
 return parse_reply(buf,ident),dt
def tcp_query(name,timeout=5):
 ident,pkt=dns_packet(name)
 with socket.create_connection(('127.0.0.1',53),timeout=timeout) as s:
  s.settimeout(timeout);t0=time.monotonic();s.sendall(struct.pack('!H',len(pkt))+pkt)
  hdr=b''
  while len(hdr)<2:chunk=s.recv(2-len(hdr));hdr+=chunk
  ln=struct.unpack('!H',hdr)[0];buf=b''
  while len(buf)<ln:chunk=s.recv(ln-len(buf));buf+=chunk
  dt=(time.monotonic()-t0)*1000
 return parse_reply(buf,ident),dt
def doh_query(name,timeout=8):
 _,pkt=dns_packet(name)
 q=base64.urlsafe_b64encode(pkt).rstrip(b'=').decode()
 ctx=ssl.create_default_context()
 t0=time.monotonic()
 raw=socket.create_connection(('127.0.0.1',10443),timeout=timeout)
 tls=ctx.wrap_socket(raw,server_hostname='manima.ru')
 note_cert(tls.getpeercert())
 tls.sendall(('GET /dns-query?dns='+q+' HTTP/1.1\r\nHost: manima.ru\r\nConnection: close\r\nAccept: application/dns-message\r\n\r\n').encode())
 resp=b''
 while True:
  try:chunk=tls.recv(65536)
  except Exception:break
  if not chunk:break
  resp+=chunk
 tls.close();dt=(time.monotonic()-t0)*1000
 head,_,body=resp.partition(b'\r\n\r\n')
 status=int(head.split(b' ',2)[1])
 if status!=200:raise ValueError('HTTP '+str(status))
 return parse_reply(body,struct.unpack('!H',pkt[:2])[0]),dt
def dot_query(name,timeout=8):
 ident,pkt=dns_packet(name)
 ctx=ssl.create_default_context()
 t0=time.monotonic()
 raw=socket.create_connection(('127.0.0.1',853),timeout=timeout)
 tls=ctx.wrap_socket(raw,server_hostname='manima.ru')
 note_cert(tls.getpeercert())
 tls.sendall(struct.pack('!H',len(pkt))+pkt)
 hdr=tls.recv(2);ln=struct.unpack('!H',hdr)[0];buf=b''
 while len(buf)<ln:buf+=tls.recv(ln-len(buf))
 tls.close();dt=(time.monotonic()-t0)*1000
 return parse_reply(buf,ident),dt
def mk(status,ms,summary,expected,actual,source='локальный зонд',target=''):
 return {'status':status,'durationMs':None if ms is None else round(ms),'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),'summary':summary,'expected':expected,'actual':actual,'source':source,'target':target}
DIAG={};DIAG_AT={}
def probe_udp():
 (rcode,ips),ms=udp_query('example.com')
 if rcode==0 and ips:return mk('pass',ms,'UDP-резолвер отвечает','NOERROR + A-запись','NOERROR, '+', '.join(ips[:3]),target='DNS · UDP')
 return mk('fail',ms,'UDP-ответ некорректен','NOERROR + A-запись','rcode='+str(rcode),target='DNS · UDP')
def probe_tcp():
 (rcode,ips),ms=tcp_query('example.com')
 if rcode==0 and ips:return mk('pass',ms,'TCP-резолвер отвечает','NOERROR + A-запись','NOERROR, '+', '.join(ips[:3]),target='DNS · TCP')
 return mk('fail',ms,'TCP-ответ некорректен','NOERROR + A-запись','rcode='+str(rcode),target='DNS · TCP')
def probe_recursive():
 tag='r%d-%d'%(int(time.time())%100000,random.randint(1000,9999))
 (rcode,ips),ms=udp_query(tag+'.example.com')
 # случайное имя не может быть в кэше: любой ответ доказывает поход во внешние NS.
 # авторитетник example.com отдаёт NXDOMAIN либо пустой NOERROR — оба варианта годятся.
 if rcode==3:return mk('pass',ms,'Сервер сам ходит во внешние NS','ответ для случайного имени','NXDOMAIN за '+str(round(ms))+' мс (кэш исключён случайным именем)',target='DNS · UDP')
 if rcode==0 and not ips:return mk('pass',ms,'Сервер сам ходит во внешние NS','ответ для случайного имени','пустой NOERROR за '+str(round(ms))+' мс (кэш исключён случайным именем)',target='DNS · UDP')
 return mk('fail',ms,'Рекурсия под вопросом','NXDOMAIN либо пустой NOERROR','rcode='+str(rcode)+', '+', '.join(ips[:3]),target='DNS · UDP')
def probe_rules():
 (rcode,ips),ms=udp_query('chatgpt.com')
 if rcode==0 and SRV_IP in ips:return mk('pass',ms,'Правило подмены работает','A = '+SRV_IP,'A = '+', '.join(ips[:3]),target='DNS · UDP')
 return mk('fail',ms,'Подмена не сработала','A = '+SRV_IP,'rcode='+str(rcode)+', '+', '.join(ips[:3]),target='DNS · UDP')
def probe_dnssec():
 (rcode,_),ms=udp_query('www.dnssec-failed.org',timeout=6)
 if rcode==2:return mk('pass',ms,'Подделка подписи отклонена','SERVFAIL для dnssec-failed.org','SERVFAIL за '+str(round(ms))+' мс',target='DNS · UDP')
 if rcode==0:return mk('warn',ms,'Валидация DNSSEC не включена','SERVFAIL для dnssec-failed.org','NOERROR — поддельный ответ принят')
 return mk('fail',ms,'Странный ответ DNSSEC-теста','SERVFAIL для dnssec-failed.org','rcode='+str(rcode),target='DNS · UDP')
def probe_doh():
 (rcode,_),ms=doh_query('example.com')
 if rcode==0:return mk('pass',ms,'DoH отвечает','HTTP 200 + NOERROR','HTTP 200, NOERROR, цепочка серта проверена',target='DoH · HTTPS')
 return mk('fail',ms,'DoH-ответ некорректен','HTTP 200 + NOERROR','rcode='+str(rcode),target='DoH · HTTPS')
def probe_dot():
 (rcode,_),ms=dot_query('example.com')
 if rcode==0:return mk('pass',ms,'DoT отвечает','NOERROR по TLS','NOERROR, цепочка серта проверена',target='DoT · TLS')
 return mk('fail',ms,'DoT-ответ некорректен','NOERROR по TLS','rcode='+str(rcode),target='DoT · TLS')
PROBES=[('recursive','Рекурсивное разрешение',probe_recursive),('dns-udp','DNS / UDP',probe_udp),('dns-tcp','DNS / TCP',probe_tcp),('rules','Правила сервисов',probe_rules),('dnssec','DNSSEC: подделка отклонена',probe_dnssec),('doh','DoH / HTTPS',probe_doh),('dot','DoT / TLS',probe_dot)]
def run_probe(pid,fn):
 try:res=fn()
 except Exception as e:res=mk('fail',None,'Проверка упала', '',type(e).__name__+': '+str(e)[:140])
 res['id']=pid;res['title']=dict((p[0],p[1]) for p in PROBES)[pid]
 with LOCK:DIAG[pid]=res;DIAG_AT[pid]=time.time()
 return res
def diag_loop():
 while True:
  for pid,_,fn in PROBES:run_probe(pid,fn)
  time.sleep(60)
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def send_json(self,obj):
  body=json.dumps(obj,separators=(',',':')).encode()
  self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def do_GET(self):
  parsed=urllib.parse.urlsplit(self.path)
  args=urllib.parse.parse_qs(parsed.query)
  if parsed.path=='/api/telemetry':
   scope='self' if args.get('scope',['self'])[0]!='all' else 'all'
   try:since=max(0,int(args.get('since',['0'])[0]))
   except ValueError:since=0
   client=self.headers.get('X-SmartDNS-Client','')
   with LOCK:
    selected=[x for x in EVENTS if scope=='all' or x['client']==client]
    protocols={x:0 for x in ['doh','dot','dns']};services={x['id']:0 for x in CATALOG};services['direct']=0
    categories={x:0 for x in ['ai','games','work','music','streams','other','direct']}
    for x in selected:protocols[x['protocol']]+=1;services[x['service']]+=1;categories[x['category']]+=1
    recent=[x for x in selected if int(x['id'])>since and (since or x['ts']>=time.time()*1000-20000)][-200:]
    rate=sum(x['count'] for x in selected if x['ts']>=time.time()*1000-10000)/10
    result={'status':'ok' if time.time()-LAST_OK<10 and time.time()-LAST_DNS_OK<15 else 'degraded','cursor':str(SEQUENCE),'serverTime':int(time.time()*1000),'scope':scope,'endpoints':ENDPOINTS,'totals':{'windowSeconds':3600,'observedSince':int(STARTED*1000),'queries':len(selected),'uniqueClients':len(set(x['client'] for x in selected)),'protocols':protocols,'services':services,'categories':categories,'rate':rate,'rateWindowSeconds':10},'events':[{k:v for k,v in x.items() if k!='client'} for x in recent]}
   self.send_json(result);return
  if parsed.path=='/api/history':
   with LOCK:mins=list(MINUTES.values())
   self.send_json({'status':'ok','serverTime':int(time.time()*1000),'startedAt':int(STARTED*1000),'scope':'all','minutes':mins});return
  if parsed.path=='/api/system':
   if time.time()*1000-SYS['at']>15000:sample_system()
   self.send_json({'status':'ok','serverTime':int(time.time()*1000),'system':SYS['data'],'cert':CERT['data'],'updatedAt':SYS['at'],'reachability':read_reachability()});return
  if parsed.path=='/api/diagnostics':
   run=args.get('run',[None])[0]
   ids=[p[0] for p in PROBES]
   if run in ids and time.time()-DIAG_AT.get(run,0)>20:
    fn=dict((p[0],p[2]) for p in PROBES)[run];run_probe(run,fn)
   with LOCK:items=[DIAG.get(pid) for pid in ids]
   items=[x for x in items if x]
   fw={'id':'firewall','title':'Сетевой экран','status':'unknown','durationMs':None,'checkedAt':None,'summary':'Нужен внешний зонд','expected':'независимая проверка портов снаружи','actual':'с сервера это не проверить — отсутствие результата не равно успеху','source':'требуется внешний агент','target':''}
   self.send_json({'status':'ok','serverTime':int(time.time()*1000),'checks':items+[fw]});return
  self.send_error(404);return

threading.Thread(target=poll,daemon=True).start()
threading.Thread(target=system_loop,daemon=True).start()
threading.Thread(target=diag_loop,daemon=True).start()
ThreadingHTTPServer(('127.0.0.1',18081),Handler).serve_forever()
