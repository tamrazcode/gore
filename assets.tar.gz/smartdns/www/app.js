(() => {
'use strict';
const $=id=>document.getElementById(id), canvas=$('flow'),ctx=canvas.getContext('2d'), format=n=>new Intl.NumberFormat('ru-RU').format(Number(n)||0);
const protocols=[{id:'doh',label:'DoH',sub:'Защищённый',color:'#83cbf0'},{id:'dot',label:'DoT',sub:'Защищённый',color:'#85bfa6'},{id:'dns',label:'DNS',sub:'Обычный',color:'#8b929c'}];
const categoryNames={all:'Все',ai:'Нейросети',games:'Игры',work:'Работа',music:'Музыка',streams:'Видео',other:'Другое'};
const fallbackNames={openai:'ChatGPT & Codex',claude:'Claude',opencode:'OpenCode',direct:'Другие сервисы'};
const PAL={bg:'#0d0e11',surface:'#17191d',border:'#2c3036',text:'#e8e3d8',muted:'#979ba3',dim:'#666c75',accent:'#83cbf0',hi:'#a6e1ff',core:'#11141a',coreBorder:'#3a4552',success:'#85bfa6'};
let catalog=[],logoMap={},catalogById={},scope='all',cursor='',totals={},particles=[],rows=['chatgpt-sora-openai','claude','opencode','direct'],width=0,height=0,online=false,lastFrame=0,lastEvent=0,seen=new Set(),controller=null,pollTimer,failures=0,filter='all',displayRate=0,targetRate=0,lastRateAt=0,rateHistory=[];
const icons=new Map();
function image(id){const url=logoMap[id]||catalogById[id]?.logo;if(!url)return null;if(!icons.has(url)){const img=new Image();img.src=url;icons.set(url,img);}return icons.get(url);}
function text(s,x,y,size,color,align='left',weight='400'){ctx.textAlign=align;ctx.font=`${weight} ${size}px Inter,system-ui,sans-serif`;ctx.fillStyle=color;ctx.fillText(s,x,y);}
function mono(s,x,y,size,color,align='left'){ctx.textAlign=align;ctx.font=`${size}px ui-monospace,Menlo,Consolas,monospace`;ctx.fillStyle=color;ctx.fillText(s,x,y);}
function geometry(){const small=width<650,displayRows=small?['chatgpt-sora-openai','claude','__other__']:rows,cols=small?3:displayRows.length;
 return{small,cols,displayRows,cx:width*.5,cy:height*(small?.47:.52),r:small?43:57,
 lanes:protocols.map((_,i)=>({x:width*(.19+i*.31),y:height*.18})),
 outs:displayRows.map((_,i)=>({x:width*((i%cols+.5)/cols),y:height*(small?(i<cols?.74:.93):.84)}))};}
function bezier(a,b,c,d,t){let k=1-t;return{x:k*k*k*a.x+3*k*k*t*b.x+3*k*t*t*c.x+t*t*t*d.x,y:k*k*k*a.y+3*k*k*t*b.y+3*k*t*t*c.y+t*t*t*d.y};}
function route(pi,slot,start){let g=geometry(),lane=g.lanes[pi],dest=g.outs[slot]||g.outs[g.outs.length-1],a=start||{x:lane.x,y:height*.04},second=g.small&&slot>=g.cols;
 return{a,b:{x:lane.x,y:g.cy*.66},c:{x:g.cx,y:g.cy-g.r-45},d:{x:g.cx,y:g.cy-g.r},e:{x:g.cx,y:g.cy-g.r},f:{x:second?g.cx+(dest.x<g.cx?-1:1)*width*.23:g.cx,y:g.cy+height*.14},h:{x:second?dest.x+width*.10:dest.x,y:dest.y-height*.13},j:{x:dest.x,y:dest.y-19}};}
function line(a,b,c,d,color,lw){ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.bezierCurveTo(b.x,b.y,c.x,c.y,d.x,d.y);ctx.strokeStyle=color;ctx.lineWidth=lw;ctx.stroke();}
function point(p,t){let q=route(p.pi,p.slot,p.start);if(t<.51)return bezier(q.a,q.b,q.c,q.d,Math.max(0,t)/.51);return bezier(q.e,q.f,q.h,q.j,(t-.51)/.49);}
function slotCount(id){if(id==='__other__')return Math.max(0,(Number(totals.queries)||0)-(Number((totals.services||{})['chatgpt-sora-openai'])||0)-(Number((totals.services||{}).claude)||0));if(id==='direct')return Math.max(0,(Number(totals.queries)||0)-rows.filter(k=>k!=='direct').reduce((n,k)=>n+(Number((totals.services||{})[k])||0),0));return Number((totals.services||{})[id])||0;}
function draw(now){ctx.clearRect(0,0,width,height);let g=geometry(),dt=lastFrame?Math.min(now-lastFrame,60):0;lastFrame=now;
 if(!document.hidden){particles.forEach(p=>p.age+=dt);particles=particles.filter(p=>p.age<p.duration);}
 let target=online&&Date.now()-lastRateAt<14000?targetRate:0;displayRate+=(target-displayRate)*(1-Math.exp(-dt/330));if(displayRate<.025)displayRate=0;
 rateHistory=rateHistory.filter(v=>Date.now()-v.time<300000);let peak=Math.max(.1,...rateHistory.map(v=>v.rate)),ratio=Math.min(1,displayRate/peak);
 // lanes: protocols on top, like before
 protocols.forEach((p,i)=>{let L=g.lanes[i],n=Number((totals.protocols||{})[p.id])||0,pc=totals.queries?Math.round(n/totals.queries*100)+'%':'—';
  text(p.label,L.x,L.y,g.small?12:14,p.color,'center','600');
  text(p.sub,L.x,L.y+17,g.small?8:10,PAL.muted,'center');
  mono(pc,L.x,L.y+33,g.small?9:10,PAL.muted,'center');});
 // service slots at the bottom, like before
 g.displayRows.forEach((id,i)=>{const dest=g.outs[i],count=slotCount(id),imageId=id==='__other__'?'direct':id;let size=g.small?24:32;ctx.save();let img=image(imageId);
  if(img&&img.complete&&img.naturalWidth)ctx.drawImage(img,dest.x-size/2,dest.y-size/2,size,size);ctx.restore();
  let name=id==='__other__'?'Другие сервисы':(catalogById[id]?.name||fallbackNames[id]||'Другие сервисы'),max=g.small?18:Math.max(14,Math.floor(width/g.cols/11));if(name.length>max)name=name.slice(0,max-1)+'…';
  let labelSize=g.small?9.5:12.5;if(g.small){ctx.font=`500 ${labelSize}px Inter,system-ui,sans-serif`;while(ctx.measureText(name).width>width/g.cols-12&&labelSize>7){labelSize-=.5;ctx.font=`500 ${labelSize}px Inter,system-ui,sans-serif`;}}
  text(name,dest.x,dest.y+(g.small?30:38),labelSize,PAL.text,'center','500');
  mono(online?format(count):'—',dest.x,dest.y+(g.small?44:56),g.small?9:10.5,PAL.muted,'center');});
 // center node, like before
 ctx.beginPath();ctx.arc(g.cx,g.cy,g.r+12,0,Math.PI*2);ctx.strokeStyle='rgba(131,203,240,.22)';ctx.lineWidth=1;ctx.stroke();
 ctx.beginPath();ctx.arc(g.cx,g.cy,g.r+5,0,Math.PI*2);ctx.strokeStyle='rgba(131,203,240,.13)';ctx.lineWidth=3;ctx.stroke();
 if(ratio>.005){ctx.save();ctx.beginPath();ctx.arc(g.cx,g.cy,g.r+5,-Math.PI/2,-Math.PI/2+ratio*Math.PI*2);ctx.strokeStyle=PAL.accent;ctx.lineWidth=3;ctx.shadowColor=PAL.accent;ctx.shadowBlur=12;ctx.stroke();ctx.restore();}
 ctx.beginPath();ctx.arc(g.cx,g.cy,g.r,0,Math.PI*2);ctx.fillStyle=PAL.core;ctx.fill();ctx.strokeStyle=PAL.coreBorder;ctx.lineWidth=1;ctx.stroke();
 text('DNS MANIMA',g.cx,g.cy-g.r-15,g.small?9:11.5,PAL.muted,'center','600');
 let rateTxt=online?new Intl.NumberFormat('ru-RU',{maximumFractionDigits:1}).format(displayRate):'—',rs=g.small?30:46;
 const setRs=s=>{ctx.textAlign='center';ctx.font=`${s}px ui-monospace,Menlo,Consolas,monospace`;};
 setRs(rs);while(ctx.measureText(rateTxt).width>g.r*1.5&&rs>14){rs-=2;setRs(rs);}
 ctx.fillStyle=PAL.text;ctx.fillText(rateTxt,g.cx,g.cy+rs*.32);
 text('запр / с',g.cx,g.cy+rs*.32+20,g.small?9:10,PAL.dim,'center');
 // particles (same pipeline as before)
 particles.forEach(p=>{if(p.age<0)return;let t=p.age/p.duration,v=point(p,t),color=protocols[p.pi].color;
  const hid=h=>{const d=Math.hypot(h.x-g.cx,h.y-g.cy);return d>g.r+6?1:Math.max(0,(d-g.r+2)/8);};
  const hv=hid(v);ctx.save();
  if(p.age<650){const k=1-p.age/650;ctx.globalAlpha=.6*k*hv;ctx.shadowColor=color;ctx.shadowBlur=18;ctx.fillStyle=color;ctx.beginPath();ctx.arc(p.start.x,p.start.y,p.radius*(2.1+1.6*k),0,Math.PI*2);ctx.fill();ctx.globalAlpha=.9*k*hv;ctx.shadowBlur=0;ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(p.start.x,p.start.y,Math.max(.6,p.radius*.45*k),0,Math.PI*2);ctx.fill();}
  ctx.lineCap='round';let pprev=null,pprevH=0;
  for(let trail=22;trail>=1;trail--){const at=t-trail*.005;if(at<0||at>.995)continue;const a=point(p,at),hh=hid(a);
   if(pprev){const f=1-trail/23;ctx.globalAlpha=.34*Math.pow(f,1.6)*((hh+pprevH)/2);ctx.strokeStyle=color;ctx.lineWidth=Math.max(.4,p.radius*(.25+f));ctx.beginPath();ctx.moveTo(pprev.x,pprev.y);ctx.lineTo(a.x,a.y);ctx.stroke();}
   pprev=a;pprevH=hh;}
  ctx.globalAlpha=.94*hv;ctx.shadowColor=color;ctx.shadowBlur=10;ctx.fillStyle=color;ctx.beginPath();ctx.arc(v.x,v.y,p.radius,0,Math.PI*2);ctx.fill();ctx.restore();});
}
function resize(){const b=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);width=b.width;height=b.height;canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);particles=[];draw(performance.now());}
/* hero: live demo resolver — real DoH answers from this server, no mocks */
function frame(now){draw(now);requestAnimationFrame(frame);}
function demoLog(cls,txt){const o=$('demo-out');o.className=cls;o.textContent=txt;}
async function demoAsk(domain){
 domain=(domain||'').trim().replace(/^https?:\/\//,'').split('/')[0].toLowerCase();
 if(!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/.test(domain)){demoLog('err','не похоже на домен: '+domain);return;}
 const btn=document.querySelector('#demo-form button[type=submit]');btn.disabled=true;
 demoLog('','спрашиваем '+domain+' у dns.manima.ru по DoH …');
 const t0=performance.now();
 try{
  const id=(Math.random()*65534+1)|0;
  const head=[id>>8,id&255,1,0,0,1,0,0,0,0,0,0];
  const body=[];domain.split('.').forEach(p=>{body.push(p.length);for(const c of p)body.push(c.charCodeAt(0));});body.push(0,0,1,0,1);
  const pkt=new Uint8Array(head.concat(body));
  let bin='';pkt.forEach(b=>bin+=String.fromCharCode(b));
  const q=btoa(bin).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
  const r=await fetch('/dns-query?dns='+q,{headers:{accept:'application/dns-message'}});
  if(!r.ok)throw new Error('HTTP '+r.status);
  const buf=new Uint8Array(await r.arrayBuffer()),ms=Math.round(performance.now()-t0);
  const dv=new DataView(buf.buffer);
  if(buf.length<12||dv.getUint16(0)!==id)throw new Error('битый ответ');
  const rcode=dv.getUint16(2)&15,anc=dv.getUint16(6);
  const skip=o=>{while(o<buf.length){const l=buf[o];if(l===0)return o+1;if(l&192)return o+2;o+=1+l;}throw new Error('битый ответ');};
  let o=skip(12)+4;const ips=[];
  for(let i=0;i<anc&&o+10<=buf.length;i++){o=buf[o]&192?o+2:skip(o);
   const typ=dv.getUint16(o),len=dv.getUint16(o+8);o+=10;
   if(typ===1&&len===4&&o+4<=buf.length)ips.push(Array.from(buf.slice(o,o+4)).join('.'));
   o+=len;}
  if(rcode===3)demoLog('err',domain+' → NXDOMAIN (имени не существует) · '+ms+' мс · DoH');
  else if(!ips.length)demoLog('err',domain+' → A-записей нет (rcode='+rcode+') · '+ms+' мс · DoH');
  else demoLog('ok',domain+' → '+ips.slice(0,4).join('\n'+domain+' → ')+(ips.length>4?'\n… +'+(ips.length-4):'')+'\n'+ms+' мс · DoH · dns.manima.ru');
 }catch(e){demoLog('err','не удалось спросить: '+e.message);}
 btn.disabled=false;
}
function status(ok){online=ok;
 const hs=$('hero-status');hs.classList.toggle('on',ok);hs.classList.toggle('bad',!ok);
 hs.lastElementChild.textContent=ok?'Сервер на связи':'Нет связи';
 const dot=document.querySelector('.hero-dot');if(dot)dot.classList.toggle('live',ok);
 const lb=$('live-badge');lb.classList.toggle('on',ok);lb.lastChild.textContent=ok?'live':'нет связи';
}
function serviceRow(id){if(width<650){if(id==='chatgpt-sora-openai')return 0;if(id==='claude')return 1;return 2;}let found=rows.indexOf(id);if(found>=0)return found;if(!catalogById[id])return rows.length-1;let slot=rows.findIndex((row,i)=>i<rows.length-1&&!particles.some(p=>p.slot===i));if(slot<0)return rows.length-1;rows[slot]=id;return slot;}
function update(data){totals=data.totals||{};targetRate=Math.max(0,Number(totals.rate)||0);lastRateAt=Date.now();rateHistory.push({time:lastRateAt,rate:targetRate});cursor=String(data.cursor??cursor);status(true);failures=0;
 $('queries').textContent=format(totals.queries);$('kpi-rate').textContent=new Intl.NumberFormat('ru-RU',{maximumFractionDigits:1}).format(targetRate);
 protocols.forEach(p=>$('metric-'+p.id).textContent=format((totals.protocols||{})[p.id]));
 $('updated').textContent=new Date().toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
 const hr=$('hero-rate'),ht=$('hero-total'),hd=$('hero-doh');
 if(hr)hr.textContent=new Intl.NumberFormat('ru-RU',{maximumFractionDigits:1}).format(targetRate);
 if(ht)ht.textContent=format(totals.queries);
 const qp=Number(totals.queries)||0,qd=Number((totals.protocols||{}).doh)||0;
 if(hd)hd.textContent=qp?Math.round(qd/qp*100)+'%':'—';
 let events=Array.isArray(data.events)?data.events:[],received=0,g=geometry();
 events.slice(-120).forEach((e,index)=>{let id=String(e.id??`${e.ts}-${e.service}-${index}-${cursor}`);if(seen.has(id))return;seen.add(id);
  let pi=protocols.findIndex(p=>p.id===e.protocol);if(pi<0)return;const count=Math.max(1,Number(e.count)||1);received+=count;lastEvent=Date.now();
  let lane=g.lanes[pi],slot=serviceRow(e.service||'direct'),dots=Math.min(12,count);
  for(let n=0;n<dots;n++){const x=lane.x+(Math.random()-.5)*width*.15,y=height*(.015+Math.random()*.09);
   particles.push({pi,slot,start:{x,y},age:-n*(150+Math.random()*110),duration:3900+Math.random()*1300,radius:1.7+Math.min(1.8,Math.log2(count/dots+1)*.45)});}});
 if(seen.size>3000)seen=new Set([...seen].slice(-1000));if(particles.length>350)particles=particles.slice(-350);
 if(totals.rate==null)totals.rate=Math.round(received/2);
 refreshStats();
 const tt=$('ticker-track');
 if(tt){const ev=events.slice(-24);tt.replaceChildren();
  if(!ev.length)tt.textContent=online?'пока тихо — события появятся с первыми запросами':'нет связи с эфиром';
  else for(let k=0;k<2;k++)ev.forEach(e=>{const pi=protocols.findIndex(p=>p.id===e.protocol),pn=pi<0?2:pi;
   const nm=(catalogById[e.service||'direct']||{}).name||e.service||'—';
   const s=document.createElement('span');s.append(' · '+nm+' ×'+Math.max(1,Number(e.count)||1)+'   —   ');
   const b=document.createElement('b');b.className='t-'+protocols[pn].id;b.textContent=protocols[pn].label;s.prepend(b);tt.append(s);});}
 if(data.endpoints)Object.entries(data.endpoints).forEach(([key,value])=>{let n=$('endpoint-'+key);if(n&&typeof value==='string')n.textContent=value;});
}
/* stats: shares + top services from the same totals */
function barRow(name,val,pct,cls){const d=document.createElement('div');d.className='meter';
 d.innerHTML=`<div class="meter-top"><b></b><span class="pct"></span></div><div class="bar ${cls||''}"><i></i></div>`;
 d.firstElementChild.firstElementChild.textContent=name;d.firstElementChild.lastElementChild.textContent=pct;
 d.lastElementChild.firstElementChild.style.width=Math.min(100,val)+'%';return d;}
function refreshStats(){
 const q=Number(totals.queries)||0,ps=$('proto-shares');ps.replaceChildren();
 protocols.forEach(p=>{const n=Number((totals.protocols||{})[p.id])||0;
  ps.append(barRow(p.label==='DNS'?'DNS · обычный':p.label+' · защищённый',q?n/q*100:0,(q?Math.round(n/q*100):0)+'% · '+format(n),p.id==='dns'?'d':''));});
 const ts=$('top-services');ts.replaceChildren();
 const top=Object.entries(totals.services||{}).filter(([id,n])=>id!=='direct'&&n>0).sort((a,b)=>b[1]-a[1]).slice(0,6);
 const mx=top.length?top[0][1]:0;
 if(!top.length){ts.innerHTML='<p class="note">Пока тихо — сервисы появятся при первых запросах.</p>';return;}
 top.forEach(([id,n])=>ts.append(barRow(catalogById[id]?.name||id,n/mx*100,format(n),'g')));
 const dir=Number((totals.services||{}).direct)||0;
 if(dir>0)ts.append(barRow('Другие сервисы',mx?dir/mx*100:0,format(dir),'d'));
}
/* history chart: real per-minute buckets */
let HIST=[];
async function loadHistory(){try{let r=await fetch('/dns/api/history',{cache:'no-store'});if(!r.ok)throw 0;let d=await r.json();HIST=d.minutes||[];
 $('hist-note').textContent=HIST.length?('последний час · с '+new Date(d.startedAt).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})):'нет данных';
 drawHistory();}catch{$('hist-note').textContent='не удалось загрузить';}}
function drawHistory(){const c=$('ratechart');if(!c)return;const b=c.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);
 c.width=Math.max(1,b.width*dpr);c.height=180*dpr;const x=c.getContext('2d');x.setTransform(dpr,0,0,dpr,0,0);
 const W=b.width,H=180;x.clearRect(0,0,W,H);const mins=HIST.slice(-60);
 if(!mins.length){x.fillStyle='#666c75';x.font='12px Inter,system-ui,sans-serif';x.fillText('История пуста — сбор идёт с момента рестарта на сервере.',12,H/2);return;}
 const mx=Math.max(1,...mins.map(m=>m.q)),pad=26;
 x.strokeStyle='#2c3036';x.lineWidth=1;[0.25,0.5,0.75].forEach(f=>{x.beginPath();x.moveTo(pad,H*f);x.lineTo(W-8,H*f);x.stroke();});
 x.fillStyle='#666c75';x.font='10px ui-monospace,monospace';
 [0,15,30,45,59].forEach(i=>{const m=mins[Math.min(i,mins.length-1)];if(!m)return;
  x.fillText(new Date(m.t).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'}),pad+(W-pad-8)*i/59-12,H-8);});
 const px=i=>pad+(W-pad-8)*i/(mins.length-1||1),py=v=>8+(H-34)*(1-v/mx);
 x.beginPath();mins.forEach((m,i)=>i?x.lineTo(px(i),py(m.q)):x.moveTo(px(i),py(m.q)));
 x.strokeStyle='#83cbf0';x.lineWidth=1.6;x.stroke();
 x.lineTo(px(mins.length-1),H-24);x.lineTo(px(0),H-24);x.closePath();x.fillStyle='rgba(131,203,240,.10)';x.fill();
 const last=mins[mins.length-1];x.fillStyle='#a6e1ff';x.font='11px ui-monospace,monospace';x.fillText(format(last.q)+'/мин',W-64,py(last.q)-6);
}
/* system */
let CPU_S=[];
async function loadSystem(){try{let r=await fetch('/dns/api/system',{cache:'no-store'});if(!r.ok)throw 0;let d=await r.json();renderSystem(d);renderReachability(d.reachability||{});}catch{ $('load-updated').textContent='не удалось опросить';}}
function renderSystem(d){const s=d.system||{};
 $('load-updated').textContent='обновлено '+new Date(d.serverTime).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
 const g=$('gauges');g.replaceChildren();
 g.append(barRow('CPU',s.cpuPct??0,(s.cpuPct??'—')+'%',''));
 const kv=(k,v)=>{const el=document.createElement('div');el.className='kv';el.innerHTML='<span></span><b></b>';el.firstElementChild.textContent=k;el.lastElementChild.textContent=v;return el;};
 const up=s.uptimeSec||0,dd=Math.floor(up/86400),hh=Math.floor(up%86400/3600);
 g.append(kv('load average',(s.loadAvg||[]).join(' · ')||'—'));
 g.append(kv('аптайм',(dd?dd+' д ':'')+hh+' ч'));
 if(typeof s.cpuPct==='number'){CPU_S.push(s.cpuPct);if(CPU_S.length>120)CPU_S.shift();drawCpu();}
 $('cert-line').innerHTML='';
 const ce=$('cert-line'),c=d.cert||{};
 ce.append(kv('сертификат manima.ru',c.daysLeft!=null?('истекает через '+c.daysLeft+' дн.'):'нет данных'));
}
function drawCpu(){const c=$('cpuchart');if(!c||CPU_S.length<2)return;const b=c.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);
 c.width=Math.max(1,b.width*dpr);c.height=64*dpr;const x=c.getContext('2d');x.setTransform(dpr,0,0,dpr,0,0);
 const W=b.width,H=64;x.clearRect(0,0,W,H);const mx=Math.max(10,...CPU_S);
 x.beginPath();CPU_S.forEach((v,i)=>{const px=i/(CPU_S.length-1||1)*W,py=H-6-(H-14)*v/mx;i?x.lineTo(px,py):x.moveTo(px,py);});
 x.strokeStyle='#83cbf0';x.lineWidth=1.4;x.stroke();}
/* diagnostics */
async function loadDiag(run){try{
 let r=await fetch('/dns/api/diagnostics'+(run?'?run='+encodeURIComponent(run):''),{cache:'no-store'});if(!r.ok)throw 0;
 let d=await r.json();renderDiag(d);}catch{}}
function renderDiag(d){const box=$('diag-list');box.replaceChildren();
 $('diag-updated').textContent='Обновлено: '+new Date(d.serverTime).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'});
 (d.checks||[]).forEach(c=>{const row=document.createElement('div');row.className='diag-row '+c.status;
  const stTxt={pass:'Пройдено',warn:'Предупреждение',fail:'Ошибка',unknown:'Не удалось проверить'}[c.status]||c.status;
  row.innerHTML=`<button class="diag-head"><i class="diag-dot"></i><span class="diag-title"></span><span class="diag-ms"></span><span class="diag-chev">▾</span></button><div class="diag-body"></div>`;
  row.firstElementChild.firstElementChild.nextElementSibling.textContent=c.title;
  row.querySelector('.diag-ms').textContent=(c.durationMs!=null?c.durationMs+' мс · ':'')+stTxt;
  const body=row.lastElementChild;
  body.innerHTML=`<p></p><div class="diag-meta"></div>`;
  body.firstElementChild.textContent=c.summary;
  const meta=body.children[1];
  [['ожидали',c.expected],['получили',c.actual],['источник',c.source+(c.target?' · '+c.target:'')],['время',c.checkedAt?new Date(c.checkedAt).toLocaleString('ru-RU'):'—']].forEach(([k,v])=>{if(!v)return;const s=document.createElement('span');s.textContent=k+': '+v;meta.append(s);});
  if(c.id!=='firewall'){const b=document.createElement('button');b.className='diag-retry';b.textContent='Повторить';b.dataset.run=c.id;
   b.addEventListener('click',ev=>{ev.stopPropagation();b.disabled=true;b.textContent='Проверяем…';loadDiag(c.id);});body.append(b);}
  row.firstElementChild.addEventListener('click',()=>row.classList.toggle('open'));
  box.append(row);});
}
function renderReachability(d){const box=$('reach-check'),title=$('reach-title'),sub=$('reach-sub'),details=$('reach-details'),summary=$('reach-summary'),list=$('reach-networks');if(!box||!title||!sub||!details||!summary||!list)return;
 const stamp=Date.parse(d.checkedAt||''),age=Number.isFinite(stamp)?Math.max(0,(Date.now()-stamp)/1000):Infinity,fresh=age<3*(Number(d.intervalSec)||1200),networks=Array.isArray(d.networks)?d.networks:[],total=Number(d.probes)||0,ok=Math.min(total,Number(d.probesOk)||0),failed=Math.max(0,total-ok),networkCount=networks.length;
 const ago=age<90?'меньше минуты назад':`${Math.round(age/60)} мин назад`,kinds={sni:'возможен сбой по имени (SNI/TLS)',ip:'TCP до адреса сервера не проходит',dns:'проба получает другой или пустой IP',tls:'TLS-соединение не завершилось',unknown:'причину определить не удалось'};
 let state='pending';
 if(!fresh){state='stale';title.textContent=Number.isFinite(stamp)?'Нет свежей проверки из российских сетей':'Проверка доступа запускается…';sub.textContent=Number.isFinite(stamp)?`Последние результаты — ${ago}.`:'Результаты появятся после первого замера.';}
 else if(d.verdict==='ok'){state='ok';title.textContent='Сайт доступен во всех проверенных сетях';sub.textContent=`${total} подключений · ${networkCount} сетей · ${ago}${d.lastError?' · не удалось обновить данные':''}`;}
 else if(d.verdict==='partial'||d.verdict==='blocked'){state=d.verdict;title.textContent=d.verdict==='blocked'?'Сайт не открылся ни в одной проверенной сети':'Сайт открывается не во всех сетях';sub.textContent=`Не прошли ${failed} из ${total} проверок · ${kinds[d.kind]||kinds.unknown} · ${ago}${d.lastError?' · новые данные получить не удалось':''}`;}
 else{state='stale';title.textContent='Проверка сейчас недоступна';sub.textContent=d.lastError||'Следующая попытка будет автоматически.';}
 box.className='reach-check '+state;details.hidden=!networks.length;summary.textContent=`Показать сети · ${total} подключений`;list.replaceChildren();
 networks.forEach(n=>{const li=document.createElement('li'),place=Array.isArray(n.cities)&&n.cities.length?' · '+n.cities.join(', '):'',status=n.state==='ok'?'доступен':n.state==='partial'?'частичный сбой':kinds[n.kind]||'не удалось проверить';li.textContent=`${n.name||'Сеть'}${place} — ${status}`;list.append(li);});}
/* guides + catalog (same logic, new skin) */
function guide(id){let g=window.MANIMA_GUIDES.find(g=>g.id===id);if(!g)return;document.querySelectorAll('[role=tab]').forEach(b=>{let active=b.dataset.guide===id;b.setAttribute('aria-selected',String(active));b.tabIndex=active?0:-1;});$('guide-panel').setAttribute('aria-labelledby','guide-'+id);$('guide-panel').innerHTML=`<div class="guide-title"><h3>${g.name}</h3><span class="guide-badge">${g.badge}</span></div><ol>${g.steps.map(s=>`<li><span>${s}</span></li>`).join('')}</ol><p class="guide-note">${g.note}</p><div class="guide-links">${g.download?`<a class="download-link" href="${g.download}">Скачать DNS-профиль</a>`:''}${g.sources.map(([n,u])=>`<a href="${u}" target="_blank" rel="noopener noreferrer">${n} ↗</a>`).join('')}</div>`;}
window.MANIMA_GUIDES.forEach((g,index)=>{let b=document.createElement('button');b.id='guide-'+g.id;b.dataset.guide=g.id;b.setAttribute('role','tab');b.setAttribute('aria-controls','guide-panel');b.textContent=g.name;b.addEventListener('click',()=>guide(g.id));b.addEventListener('keydown',e=>{if(!['ArrowRight','ArrowLeft','ArrowDown','ArrowUp','Home','End'].includes(e.key))return;e.preventDefault();let tabs=window.MANIMA_GUIDES,step=['ArrowRight','ArrowDown'].includes(e.key)?1:-1,i=e.key==='Home'?0:e.key==='End'?tabs.length-1:(index+step+tabs.length)%tabs.length;guide(tabs[i].id);$('guide-'+tabs[i].id).focus();});$('guide-tabs').append(b);});guide('windows11');
function renderCatalog(){let search=$('service-search').value.trim().toLocaleLowerCase('ru-RU'),visible=catalog.filter(s=>(filter==='all'||s.category===filter)&&`${s.name} ${s.domain} ${(s.domains||[]).join(' ')}`.toLocaleLowerCase('ru-RU').includes(search));$('catalog').replaceChildren();visible.forEach(s=>{let a=document.createElement('a');a.className='service-card';a.href=s.url||s.website;a.target='_blank';a.rel='noopener noreferrer';let img=document.createElement('img');img.className='service-logo';img.alt='';img.src=logoMap[s.id]||s.logo;img.loading='lazy';img.decoding='async';let meta=document.createElement('div');meta.className='service-meta';let name=document.createElement('span');name.className='service-name';name.textContent=s.name;let domain=document.createElement('span');domain.className='service-domain';domain.textContent=s.domain;meta.append(name,domain);a.append(img,meta);$('catalog').append(a);});$('catalog-empty').hidden=visible.length>0;}
async function loadCatalog(){try{const [cr,lr]=await Promise.all([fetch('/dns/catalog.json',{cache:'no-store'}),fetch('/dns/logo-map.json',{cache:'no-store'})]);if(!cr.ok||!lr.ok)throw Error('Catalog');let c=await cr.json();catalog=Array.isArray(c)?c:c.services||[];logoMap=await lr.json();catalogById=Object.fromEntries(catalog.map(s=>[s.id,s]));let defaults=['chatgpt-sora-openai','claude','opencode'];rows=[...defaults.filter(id=>catalogById[id]),'direct'];for(let key of Object.keys(categoryNames)){if(key!=='all'&&!catalog.some(s=>s.category===key))continue;let b=document.createElement('button');b.textContent=categoryNames[key];b.classList.toggle('active',key===filter);b.setAttribute('aria-pressed',String(key===filter));b.addEventListener('click',()=>{filter=key;document.querySelectorAll('#category-filters button').forEach(n=>{n.classList.toggle('active',n===b);n.setAttribute('aria-pressed',String(n===b));});renderCatalog();});$('category-filters').append(b);}$('catalog-summary').textContent=`${format(catalog.length)} сервисов в каталоге`;renderCatalog();}catch{$('catalog-summary').textContent='Список временно недоступен';$('catalog-empty').hidden=false;$('catalog-empty').textContent='Не удалось загрузить каталог. Обновите страницу позже.';}}
async function poll(){let own=new AbortController();controller=own;let timer=setTimeout(()=>own.abort(),9000);try{let r=await fetch(`/dns/api/telemetry?scope=${scope}&since=${encodeURIComponent(cursor)}`,{cache:'no-store',signal:own.signal});if(!r.ok)throw Error('Unavailable');let data=await r.json();if(controller!==own)return;const time=typeof data.serverTime==='number'?data.serverTime:Date.parse(data.serverTime);if(data.status!=='ok'||!Number.isFinite(time)||Math.abs(Date.now()-time)>45000)throw Error('Stale');update(data);}catch{if(controller!==own)return;failures++;status(false);particles=[];}finally{clearTimeout(timer);if(controller===own){controller=null;pollTimer=setTimeout(poll,failures?Math.min(10000,2000*failures):2000);}}}
$('service-search').addEventListener('input',renderCatalog);
document.querySelectorAll('[data-copy]').forEach(b=>b.addEventListener('click',async()=>{try{await navigator.clipboard.writeText($(b.dataset.copy).textContent);$('copy-status').textContent='Скопировано';}catch{$('copy-status').textContent='Выделите и скопируйте адрес вручную';}setTimeout(()=>$('copy-status').textContent='',2500);}));
/* nav */
const nav=$('sitenav');
addEventListener('scroll',()=>{nav.classList.toggle('show',scrollY>innerHeight*.75);},{passive:true});
try{const secs=[...document.querySelectorAll('main .block')],links=[...nav.querySelectorAll('.sitenav-links a')];
 const io=new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting)links.forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+e.target.id));});},{rootMargin:'-40% 0px -55% 0px'});
 secs.forEach(s=>io.observe(s));}catch(e){}
addEventListener('resize',()=>{resize();drawHistory();});document.addEventListener('visibilitychange',()=>{if(document.hidden)particles=[];});
resize();requestAnimationFrame(frame);loadCatalog();poll();loadHistory();loadSystem();loadDiag();
try{const df=$('demo-form');if(df){df.addEventListener('submit',e=>{e.preventDefault();demoAsk($('demo-input').value);});df.querySelectorAll('[data-demo]').forEach(b=>b.addEventListener('click',()=>{$('demo-input').value=b.dataset.demo;demoAsk(b.dataset.demo);}));}}catch(e){}
setInterval(loadHistory,60000);setInterval(loadSystem,15000);setInterval(loadDiag,60000);
})();
